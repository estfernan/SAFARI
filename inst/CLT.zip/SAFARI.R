#!/usr/bin/env Rscript

# ******************************************************************************
#
# A command line tool for the SAFARI package.
#
# Usage:     Rscript --vanilla SAFARI.R file output min.area n.largest
#
# Arguments: file      = character string that specifies the location of the
#                        image (PNG, GIF, or RData) to read and pre-process
#            output    = character string that specifies where to store outputs
#            min.area  = minimum net area for filtering procedure
#            n.largest = number of regions to keep for filtering procedure
#
# Authors:   Esteban Fernández and Qiwei Li
# Notes:     If NA's are passed to both min.area and n.largest, then the minimum
#            net area will be set as one-fourth the area of the largest region.
#            We also note that the arguments 'min.area' and 'n.largest' cannot
#            be simultaneously specified.
#
# Example:   Rscript --vanilla SAFARI.R
#            samples/image004.png
#            external/output/results
#            NA NA
#
# See ?binary.segmentation from SAFARI package for more information.
#
# ******************************************************************************
#
# R package SAFARI by Esteban Fernández and Qiwei Li
# Copyright (C) 2021
#
# This file is part of the R package SAFARI.
#
# The R package SAFARI is free software: You can redistribute it and/or
# modify it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or any later
# version (at your option). See the GNU General Public License at
# <https://www.gnu.org/licenses/> for details.
#
# The R package SAFARI is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
#
# ******************************************************************************

# clear environment
rm(list = ls())

# potential errors
errors <- c(
    "command line arguments must be passed : no arguments parsed",
    "arguments 'min.area' and 'n.largest' cannot be simultaneously specified",
    "image in 'file' could not be read : extension not supported",
    "image in 'file' is non-binary",
    "image in 'file' appears to be empty",
    "argument 'x' is an empty matrix",
    "no regions of interest present after filtering procedure"
)

# ||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||
# Start defining functions ----
# ||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||

## Binary segmentation ----

binary.segmentation <- function(
    x, id, filter = NA,
    categories = c("none", "geometric", "boundary", "topological")
)
{
    # empty image check
    if (is.empty(x))
    {
        stop("argument 'x' is an empty matrix")
    }

    # empty ID's
    if (length(id) == 3 & !is.named(id))
    {
        names(id) <- c("cohort", "patient.id", "slide.id")
    }

    # categories check
    v <- ifelse("none" %in% categories, NA, 0)

    # initial values
    n <- length(filter)

    # default filters
    min.area  <- NA
    n.largest <- NA
    minimum   <- NA

    # argument length check
    if (n > 2)
    {
        warning("only the first two elements in 'filter' will be used")
    }

    # filtering check
    if (n == 2)
    {
        minimum   <- filter[1]
        n.largest <- filter[2]
    }
    else if (n == 1)
    {
        if (!is.na(filter))
        {
            min.area  <- filter
        }
    }

    # identify and segment tumor regions
    seg <- image.fsf(x,
                     min.area = min.area,
                     n.largest = n.largest,
                     minimum = minimum
    )

    # number of tumors
    s <- max(seg)

    # no regions after filtering
    if (s <= 0)
    {
        stop("no regions of interest present after filtering procedure")
    }

    # segmented shape objects
    regions    <- seg * x
    holes      <- seg - regions
    plg.chains <- polygonal.chain.list(seg, 3)

    # compute shape features
    if (!is.na(v))
    {
        v <- compute.features.list(regions, plg.chains, id, categories)
    }

    # prepare results
    list(desc = v,
         holes      = holes,
         id         = id,
         n          = s,
         plg.chains = plg.chains,
         regions    = regions)
}

## Compute features ----

compute.features <- function(
    region, plg.chain,
    categories = c("geometric", "boundary", "topological")
)
{
    # empty object
    desc <- c()

    # shape features
    if ("geometric" %in% categories)
    {
        desc <- c(
            desc,
            geometric.features(region, plg.chain)
        )
    }

    # boundary features
    if ("boundary" %in% categories)
    {
        desc <- c(
            desc,
            boundary.features(plg.chain)
        )
    }

    # topological features
    if ("topological" %in% categories)
    {
        desc <- c(
            desc,
            topological.features(region)
        )
    }

    return(desc)
}

compute.features.list <- function(regions, plg.chains, id, categories)
{
    # number of regions
    s <- max(regions)

    # allocate storage
    v <- vector("list", s)

    # compute individual features
    for (i in 1:s)
    {
        # objects
        region     <- (regions == i)
        plg.chain  <- plg.chains[[i]]

        # descriptors
        v[[i]] <- c(
            region.id = i,
            compute.features(region, plg.chain, categories = categories)
        )
    }

    # merge results
    data.frame(
        t(id),
        do.call(rbind, v)
    )
}

## Features ----

geometric.features <- function(R, P)
{
    # shape representations
    P.CH  <- convex.hull(P)
    P.MBB <- minimum.bounding.box(P.CH)

    # compute descriptors
    c(
        region.based(R),
        polygonal.based(P),
        convex.hull.based(P, P.CH),
        bounding.box.based(P, P.MBB)
    )
}

boundary.features <- function(P)
{
    # shape representations
    cc <- chain.code(P)
    k  <- curvature.chain(cc)
    r  <- radial.lengths(P)

    # compute descriptors
    c(
        curvature.chain.based(k),
        radial.lengths.based(r)
    )
}

topological.features <- function(R)
{
    # quantities
    f.H <- image.fill(R)
    H   <- f.H - R
    f.S <- image.segment(H)
    B   <- matrix(1, 3, 3)

    # de-noise region
    R.hat <- image.opening(
        image.erode(f.H, B), B
    )

    # compute descriptors
    c(
        number.holes       = max(f.S),
        number.protrusions = ifelse(is.empty(R.hat), 0, sum(f.H - R.hat))
    )
}

region.based <- function(R)
{
    # quantities
    A <- sum(R)
    d <- thickness(R)

    # compute descriptors
    c(
        net.area   = A,
        thickness  = d,
        elongation = A / (2 * d^2)
    )
}

polygonal.based <- function(P)
{
    # quantities
    A   <- gauss.area(P)
    Per <- perimeter(P)

    # compute descriptors
    c(
        area.filled = A,
        perimeter   = Per,
        circularity = (4*pi) * A / Per^2
    )
}

convex.hull.based <- function(P, P.CH)
{
    # quantities
    Area.Filled <- gauss.area(P)
    Area        <- gauss.area(P.CH)
    Per         <- perimeter(P.CH)

    # compute descriptors
    c(
        convex.area = Area,
        convex.perimeter = Per,
        roundness = (4*pi) * Area.Filled / Per^2,
        convexity = Per / perimeter(P),
        solidity = Area.Filled / Area
    )
}

bounding.box.based <- function(P, P.MBB)
{
    # initial values
    b <- diff(P.MBB)        # differences
    l <- sqrt(rowSums(b^2)) # lengths
    k <- which.max(l)       # index of max length

    # remove names
    dimnames(b) <- NULL

    # quantities
    l.max <- max(l)
    l.min <- min(l)

    # fibre measurements
    l <- fibre.length(P)
    w <- fibre.width(P)

    # compute descriptors
    c(
        major.axis.length = l.max,
        major.axis.angle  = atan2(b[k, 2], b[k, 1]), # subtract by pi
        minor.axis.length = l.min,
        bounding.box.area = l.max * l.min,
        eccentricity      = l.min / l.max,
        fibre.length      = l,
        fibre.width       = w,
        curl              = l.max / l
    )
}

curvature.chain.based <- function(k)
{
    c(
        bending.energy      = mean(k^2),
        total.abs.curvature = mean(abs(k))
    )
}

radial.lengths.based <- function(r)
{
    # quantities
    n     <- length(r)
    m     <- mean(r)
    sigma <- stdv(r)

    # boolean values
    below <- r <= m
    above <- r >= m

    # measurements
    Z  <- sum(below  & c(FALSE, above[-n])) + sum(above  & c(FALSE, below[-n]))
    Nm <- (mean((r - m)^4)^(1/4) - mean((r - m)^2)^(1/2)) / m

    # compute descriptors
    c(
        radial.mean       = m,
        radial.sd         = sigma,
        entropy           = radial.entropy(r),
        area.ratio        = (1 / (n*m)) * sum(r[above] - m),
        zero.crossing     = Z,
        normalized.moment = Nm
    )
}

## Image operations ----

image.contour <- function(img)
{
    ocontour(img)
}

image.erode <- function(img, k)
{
    erode(img, k)
}

image.fill <- function(img)
{
    fillHull(img)
}

image.opening <- function(img, k)
{
    opening(img, k)
}

image.segment <- function(img)
{
    bwlabel(img)
}

image.fsf <- function(img, min.area, n.largest, minimum)
{
    filter.segments(
        image.segment(
            image.fill(img)
        ), min.area = min.area, n.largest = n.largest, minimum = minimum
    )
}

image.border <- function(image, val, width)
{
    # vertical border
    v <- matrix(val, nrow = nrow(image), ncol = width)

    # add left-right borders
    image <- cbind(v, image, v)

    # horizontal border
    h <- matrix(val, nrow = width, ncol = ncol(image))

    # add top-bottom border
    image <- rbind(h, image, h)

    # end procedure
    return(image)
}

image.enlarge <- function(img, k)
{
    # obtain dimensions of the img
    rows <- dim(img)[1]; cols <- dim(img)[2]

    # create enlarged img matrix
    enlarged <- matrix(0, nrow = k * rows, ncol = k * cols)

    # populate matrix from original img
    for (i in 1:rows)
    {
        for (j in 1:cols)
        {
            for (ii in (k*(i - 1) + 1):(k*i))
            {
                for (jj in (k*(j - 1) + 1):(k*j))
                {
                    enlarged[ii, jj] <- img[i, j];
                }
            }
        }
    }

    enlarged
}

filter.segments <- function(seg, min.area = NA, n.largest = NA, minimum = 5)
{
    # net area for regions (sorted and w/o zero index)
    area <- sort(table(seg)[-1], decreasing = TRUE)

    # number of regions
    n <- length(area)

    # no regions
    if (n <= 0)
    {
        return(seg)
    }

    # compute minimum net area
    if (is.na(min.area))
    {
        if (!is.na(n.largest))
        {
            min.area <- area[ifelse(n.largest > n, n, n.largest)]

            if (min.area < minimum)
            {
                min.area <- minimum
            }
        }
        else
        {
            min.area <- max(area) / 4
        }
    }

    # regions to keep (logical)
    bool <- area >= min.area

    # re-shape kept segments
    new <- matrix(match(seg, names(area)[bool], nomatch = 0),
                  nrow = nrow(seg),
                  ncol = ncol(seg))

    # store removed regions (add argument: islands = FALSE)
    # if (islands)
    # {
    #     islands <- (seg != 0L) - (new != 0L)
    #     new <- list(seg = new, islands = islands)
    # }

    # end of procedure
    return(new)
}

## Miscellaneous ----

centroid <- function(P)
{
    # number of boundary points
    n <- nrow(P) - 1

    # compute area of shape
    A <- gauss.area(P, signed = TRUE)

    # initialize centroid
    cent <- c(x = 0, y = 0)

    # compute the shape's centroid
    for (i in 1:n)
    {
        # multiplication factor
        s <- P[i, 1] * P[i + 1, 2] - P[i + 1, 1] * P[i, 2]

        # update the x-coordinate
        cent["x"] <- cent["x"] + (P[i, 1] + P[i + 1, 1]) * s

        # update the y-coordinate
        cent["y"] <- cent["y"] + (P[i, 2] + P[i + 1, 2]) * s
    }

    # divide by factor
    cent / (6 * A)
}

fibre.length <- function(P) {
    # quantities for shape
    A   <- gauss.area(P)
    Per <- perimeter(P)

    # discriminant
    D <- Per^2 - 16 * A

    # check for invalid computation
    if (D < 0)
    {
        return(NA)
    }

    # compute fibre length
    (Per - sqrt(D)) / 4
}

fibre.width <- function(P)
{
    gauss.area(P) / fibre.length(P)
}

gauss.area <- function(P, signed = FALSE)
{
    # initial values
    n <- nrow(P) - 1    # number of points
    A <- 0              # counter
    dimnames(P) <- NULL # remove names

    # shoelace formula
    for (i in 1:n)
    {
        A <- A + (
            P[i, 1] * P[i + 1, 2] - P[i + 1, 1] * P[i, 2]
        )
    }

    # obtain un-signed area
    if (!signed)
    {
        A <- abs(A)
    }

    # apply constant
    (1/2) * A
}

perimeter <- function(P)
{
    sum(sqrt(rowSums(diff(P)^2)))
}

radial.entropy <- function(r, delta = 0.01)
{
    p.k   <- hist(r, breaks = seq(0, 1, by = delta), plot = FALSE)$density / 100
    -sum(p.k * log(p.k), na.rm = TRUE)
}

stdv <- function(x, na.rm = FALSE)
{
    x.hat <- mean(x)
    sqrt(mean((x - x.hat)^2))
}

thickness <- function(R)
{
    # initial values
    k <- matrix(1, 3, 3) # kernel brush
    R <- image.fill(R)   # fill holes
    d <- 0               # thickness variable
    A <- sum(R)          # initial area

    # compute thickness
    while (sum(R) > 0)
    {
        R <- image.erode(R, k) # erode image
        d <- d + 1                # increase thickness

        # prevent infinite loop
        if (sum(R) == A)
        {
            return(NA)
        }
    }

    return(d)
}

arctan2 <- function(v)
{
    atan2(v[2], v[1])
}

is.binary <- function(img)
{
    length(table(img)) == 2
}

is.empty <- function(x)
{
    sum(x) <= 0
}

is.named <- function(x)
{
    !is.null(names(x))
}

## Reconstruction plot ----

rc.plot <- function(x, type = c("binary", "seg"), publication = FALSE, ...)
{
    # dimensions
    L <- nrow(x) # x-value
    W <- ncol(x) # y-value

    # number of regions
    s <- max(x)

    # colors and labels
    info <- switch(type,
                   binary = list(cols = 1:0, labels = c("Empty", "Tumor")),
                   seg = list(cols = 0:s, labels = 0:s),
                   stop("argument 'type' is not a valid option")
    )

    # publication style
    if (publication)
    {
        # hide scales
        scales <- list(x = list(at = NULL), y = list(at = NULL))

        # hide color key
        region <- FALSE
    }

    # default style
    else
    {
        # left-bottom axes
        scales <- list(tck = 1:0)

        # properly segment key
        region <- list(labels = list(at = seq(.5, s + 1, 1), labels = info$labels))
    }

    # create figure
    levelplot(x, aspect = "iso",
              scales = scales,
              xlab = "", xlim = c(0, L),
              ylab = "", ylim = c(0, W),
              at = 0:(s + 1) - 0.1,
              pretty = TRUE,
              useRaster = FALSE,
              colorkey = region,
              col.regions = info$cols,
              ...)
}

## Read binary image ----

read.image <- function(file)
{
    # error message for loading image
    msg <- "image in 'file' could not be read : extension not supported"

    # attempt to load image, base on file extension
    ext <- tolower(file_ext(file))
    img <- switch(ext,
                  gif = read.gif(file)$image,
                  png = readPNG(file),
                  rdata = get(load(file)),
                  stop(msg))

    # number of channels
    n <- dim(img)[3]

    # multiple channels check
    if (!is.na(n))
    {
        if (n == 2)
        {
            img <- img[,,1]
        }
        else
        {
            img <- img[,,2]
        }
    }

    # binary image check
    if (!is.binary(img))
    {
        stop("image in 'file' is non-binary")
    }

    # empty matrix check
    if (is.empty(img))
    {
        stop("image in 'file' appears to be empty")
    }

    # image pre-processing
    img[img > 0] <- 1              # ensure image is binary
    img <- image.border(img, 0, 5) # expand image border

    # rotate image
    if (ext != "rdata")
    {
        img <- t(img)[, nrow(img):1]
    }

    # modify to integer
    mode(img) <- "integer"

    # end of procedure
    return(img)
}

## Shape representations ----

polygonal.chain <- function(R, k = 1)
{
    # enlarge regions
    if (k > 1)
    {
        R <- image.enlarge(R, k = k)
    }

    # extract contour
    contr <- image.contour(R)[[1]]

    # find duplicate entries
    dups <- duplicated(contr)

    # validate chain
    if (sum(dups) > 0)
    {
        stop("a polygonal chain could not be created from the region")
    }

    create.chain(contr)
}

convex.hull <- function(P)
{
    # open chain
    P <- P[-nrow(P), ]

    # index of points that make up the convex hull
    index <- chull(P)

    # create the convex hull chain
    P.CH <- P[index, ]
    create.chain(P.CH)
}

minimum.bounding.box <- function(P.CH)
{
    # directions of edges
    e <- diff(P.CH)

    # lengths of edges
    lengths <- sqrt(rowSums(e^2))

    # unit edge directions
    v <- e / lengths

    # normal directions to edges
    w <- cbind(v[,2], -v[,1]) # original has -v[,2], v[,1]

    # find the MAR
    x <- apply(P.CH %*% t(v), 2, range) # extremes along edges
    y <- apply(P.CH %*% t(w), 2, range) # extremes normal to edges

    # compute possible areas
    areas <- (y[1, ] - y[2, ]) * (x[1, ] - x[2, ])

    # index of the edge with the smallest area
    k <- which.min(areas)

    # form bounding box from extremes of the chosen edge
    rect <- cbind(x[c(1, 2, 2, 1, 1), k], y[c(1, 1, 2, 2, 1), k])

    # orient the bounding box to the correct angle
    rect %*% rbind(v[k, ], w[k, ])
}

chain.code <- function(P)
{
    # difference between consecutive points
    D <- diff(P)

    # angle between difference and x-axis
    theta <- apply(D, 1, arctan2)

    # modify angle
    theta <- ifelse(theta >= 0, theta, theta + 2*pi)

    # compute corresponding chain code
    round(theta / (pi / 4))
}

curvature.chain <- function(cc)
{
    # difference between consecutive chain codes
    k <- diff(cc)

    # modify negative entries
    k[k < 2] <- k[k < 2] + 8

    # modify positive entries
    k[k > 2] <- k[k > 2] - 8

    # end procedure
    k
}

radial.lengths <- function(P, normalize = TRUE)
{
    # shape's centroid
    ct <- centroid(P)

    # compute the radial lengths
    r <- sqrt(rowSums(sweep(P, 2, ct)^2))

    # normalize the lengths
    if (normalize)
    {
        r <- r / max(r)
    }

    # delete duplicate entry
    r[-length(r)]
}

create.chain <- function(V)
{
    # modify columns
    colnames(V) <- c("X", "Y")

    # TODO: check that polygon is clockwise
    # TODO: find starting point (based on criteria)

    # close off chain
    rbind(V, V[1, ])
}

polygonal.chain.list <- function(seg, k = 1)
{
    # enlarge regions
    if (k > 1)
    {
        seg <- image.enlarge(seg, k = k)
    }

    # extract contours
    contr <- image.contour(seg)

    # find duplicate entries
    dups <- unlist(
        sapply(contr, duplicated)
    )

    # validate chain
    if (sum(dups) > 0)
    {
        stop("a polygonal chain could not be created from one of the regions")
    }

    # create polygonal chain
    lapply(contr, function(x)
    {
        # modify columns names
        colnames(x) <- c("X", "Y")

        # TODO: check that polygon is clockwise
        # TODO: find starting point (based on criteria)

        # create polygonal chain
        rbind(x, x[1, ])
    }
    )
}

# ||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||
# Command line code ----
# ||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||

tryCatch(
    {
        suppressWarnings(
            {
                # load libraries
                library(caTools)
                library(EBImage)
                library(jsonlite)
                library(lattice)
                library(png)
                library(tools)

                ## prepare arguments ----

                # parse arguments
                args <- commandArgs(trailingOnly = TRUE)
                n    <- length(args)

                # arguments check
                if (n <= 0)
                {
                    stop("command line arguments must be passed : no arguments parsed")
                }

                ## error file ----

                # parse file
                loc <- args[2]
                str <- strsplit(loc, "/")[[1]]
                n   <- length(str)

                # create file
                sink(
                    paste0(
                        ifelse(n > 1, paste(str[1:(n - 1)], collapse = "/"), "."),
                        "/error_",
                        str[n], ".txt"
                    )
                )

                # check filters ----

                # filtering check
                if (args[3] != "NA" & args[4] != "NA")
                {
                    stop("arguments 'min.area' and 'n.largest' cannot be simultaneously specified")
                }

                # prepare filter(s)
                if (args[4] != "NA")
                {
                    filter <- as.integer(
                        args[3:4]
                    )

                    if (args[3] == "NA")
                    {
                        filter[1] <- 5
                    }
                }
                else
                {
                    filter <- as.integer(args[3])
                }

                ## ROI segmentation and feature extraction ----

                # read file
                img <- read.image(args[1])

                # segmentation procedure
                ext <- binary.segmentation(img, id = 0, filter = filter, categories = "geometric")

                ## clean and export results ----

                # prepare final data
                R    <- ext$regions
                v    <- ext$desc[, -1]
                cols <- colnames(v)

                # modify columns
                colnames(v)    <- toTitleCase(gsub("[.]", " ", cols))
                colnames(v)[1] <- "Region ID"

                # convert data
                v <- data.matrix(v)
                class(v) <- "character"

                # prepare figures (PNG)
                png(file = paste0(loc, ".png"), width = 3600, height = 2400, pointsize = 12, bg = NA, res = 300)
                gridExtra::grid.arrange(
                    rc.plot(img, "binary"),
                    rc.plot(R, "seg"),
                    ncol = 2
                )
                dev.off()

                # save features (JSON)
                conn <- file(paste0(loc, ".txt"))
                writeLines(toJSON(rbind(colnames(v), v)), conn)
                close(conn)
            }
        )
    },
    error = function(e)
    {
        cat(
            which(
                sapply(errors, grepl, toString(e), fixed = TRUE)
            ), "\n"
        )
    }
)

# close file
sink()
