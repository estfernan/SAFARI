# ******************************************************************************
#
# A simple script to install the package dependencies for the CLT.
#
# Authors:   Esteban Fernández and Qiwei Li
# Notes:     The package EBImage is only available through Bioconductor.
#
# ******************************************************************************
#
# R package SAFARI by Esteban Fernández and Qiwei Li
# Copyright (C) 2021
#
# This file is part of the R package SAFARI.
#
# The R package SAFARI is free software: You can redistribute it and/or
# modify it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or any later
# version (at your option). See the GNU General Public License at
# <https://www.gnu.org/licenses/> for details.
#
# The R package SAFARI is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
#
# ******************************************************************************

# necessary packages
pkgs <- c("caTools", "EBImage", "gridExtra", "jsonlite", "lattice", "png", "tools")

# current packages
old <- rownames(
    installed.packages()
)

# install Bioconductor repository
if (!requireNamespace("BiocManager", quietly = TRUE))
{
    install.packages("BiocManager")
}

# install packages
BiocManager::install("EBImage")
install.packages(pkgs[!(pkgs %in% old)])
